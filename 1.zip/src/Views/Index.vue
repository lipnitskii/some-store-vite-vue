<template>
  <div>
    <Hero />
    <AboutBrand />
    <PopularProducts /> 
    <Ideas />
    <Subscribe />
  </div>
</template>

<script setup>
import Hero from "@/components/Hero.vue";
import AboutBrand from "@/components/AboutBrand.vue";
import Ideas from "@/components/Ideas.vue";
import Subscribe from "@/components/Subscribe.vue";
import PopularProducts from "@/components/PopularProducts.vue";
</script>
