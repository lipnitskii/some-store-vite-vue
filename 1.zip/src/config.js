export default {
    MOCK: "https://fakestoreapi.com/",
  };